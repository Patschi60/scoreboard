        <div class="hilfebox">
            <h2>Kleine Hilfe</h2>

            <h3>Beim Start:</h3>
            <p>Nach dem Einloggen öffnen sich 2 Browser-Tabs.</p>
            <p>Den Tab mit der Beamer-Anzeige per Maus auf den Beamer ziehen und mit der "F11"-Taste den Vollbildmodus aktivieren.</p>
            
            <h3>Bei Auswechslungen:</h3>
            <p>Die beiden Spielernamen mit einem / trennen.<br>
            (z.B. Albert Haller/Matthias Eck)<br>
            Die Beamer-Anzeige gibt die Namen dann in 2 Zeilen aus.</p>

            <h3>Achtung:</h3>
            <p>Wenn sich keine Beamer-Anzeige öffnet, Popup-Fenster erlauben (Symbol am rechten Rand der Browser-Adresszeile).<br>
            Müsste am SCH-Laptop aber bereits eingestellt sein.</p>
        </div>