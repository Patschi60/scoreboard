<html>
<head>

<title>Scoreboard</title>
<meta charset="utf-8">
<meta name="google" value="notranslate">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no, user-scalable=no">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black">

<link rel="apple-touch-icon" href="icon/apple-icon-144x144.png"/>
<link rel="apple-touch-icon" sizes="72x72" href="icon/apple-icon-72x72.png"/>
<link rel="apple-touch-icon" sizes="114x114" href="icon/apple-icon-114x114.png"/>
<link rel="apple-touch-icon" sizes="144x144" href="icon/apple-icon-144x144.png"/>

<link rel="stylesheet" href="resources/mobile.css">
</head>

    <body>
    <center>
        <h1>Scoreboard</h1>

        <form action="mobile/logincheck.php" Method="post">
            <table>
                <tr><td><input class="name" placeholder="Benutzername" name="user" size="20"></td></tr>
                <tr><td><input class="name" placeholder="Passwort" type="password" name="pw" size="20"></td></tr>
                <tr><td><input class="speichern" style="font-size:25px;" type="submit" value="login"></td></tr>
            </table>
        </form>

    </center>
    </body>
</html>