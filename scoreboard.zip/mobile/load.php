<?php
header("Location:logedin.php");
exit();
?>