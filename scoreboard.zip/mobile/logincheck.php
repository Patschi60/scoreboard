<?php
include("../core/logincheck.php");
?>