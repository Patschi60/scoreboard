<?php
include("../core/delete.php");
?>